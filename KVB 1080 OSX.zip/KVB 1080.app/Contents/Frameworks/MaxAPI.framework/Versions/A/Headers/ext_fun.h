/*************************/
/* Copyright 1988 IRCAM. */
/*************************/

#ifndef _EXT_FUN_H_
#define _EXT_FUN_H_

// 	NOTE: This file is obsolete.

#endif /* _EXT_FUN_H_ */
